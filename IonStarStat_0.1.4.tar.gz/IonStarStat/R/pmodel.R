## pmodel <-
## function(dfm1, pmethod){
##     lm1 <- NA
##     if(any(duplicated(dfm1$variable))){
##         try(lm1 <- glmer(value~1+TREAT+(1|variable)+(1|Peptide/Frame), data=dfm1), silent==TRUE)
##     }else if(any(duplicated(dfm1$Frame))){
##         try(lm1 <- glmer(value~1+TREAT+(1|Peptide/Frame), data=dfm1), silent==TRUE)
##     }else{
##         try(lm1 <- glm(value~1+TREAT, data=dfm1), silent==TRUE)
##     }

##     if(is.null(slotNames(lm1))){
##         lm1c <- rep(NA, 4)
##     }else{
##         lm1c <- coef(summary(lm1))[2,]
##         lm1p <- 0
##         if(pmethod=="MCMC"){       
##             try(lm1p <- as.numeric(pvals.fnc(lm1, addPlot=FALSE)$fixed[2,6]), silent=TRUE)#MCMC
##         #}else if(pmethod=="MLE"){
##         #    try(lm1p <- as.numeric(p.values.lmer(lm1)@coefs[2,4]), silent=TRUE)#MLE
##         }else{
##             stop("Wrong method!")
##         }
##         lm1c <- c(lm1c, p.value=lm1p)
##     }
##     return(lm1c)
## }

pmodel <- function(dfm1){
    #no compare group
    if(length(unique(dfm1$TREAT))<2){
        lm1c <- rep(NA, 4)
        names(lm1c) <- c("post.mean", "l-95% CI", "u-95% CI", "pMCMC")
        warning(paste("Only", length(unique(dfm1$TREAT)), "group for", dfm1$Protein[1]))
        return(lm1c)
    }
    lm1 <- NA    
    #glmm
    if("Frame" %in% colnames(dfm1)){
        if(any(duplicated(dfm1$variable))){
            try(lm1 <- MCMCglmm(value~TREAT, random=~variable + Frame + Frame:Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
        }else if(any(duplicated(dfm1$Frame))){
            try(lm1 <- MCMCglmm(value~TREAT, random=~Frame + Frame:Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
        }else{
            lm1 <- glm(value~1+TREAT, data=dfm1)
        }
    }else{   
        if(any(duplicated(dfm1$variable))){
            try(lm1 <- MCMCglmm(value~TREAT, random=~variable + Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
        }else if(any(duplicated(dfm1$Peptide))){
            try(lm1 <- MCMCglmm(value~TREAT, random=~Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
        }else{
            lm1 <- glm(value~1+TREAT, data=dfm1)
        }
    }
    
    if(class(lm1)=="MCMCglmm"){
        lm1c <- summary(lm1)$solutions[2,c(1,2,3,5)]
    }else{
        lm1 <- glm(value~1+TREAT, data=dfm1)
        lm1c <- summary(lm1)$coefficients[2,]
        lm1c[2:3] <- confint(lm1, parm=2)
    }
    names(lm1c) <- c("post.mean", "l-95% CI", "u-95% CI", "pMCMC")
    return(lm1c)
}
