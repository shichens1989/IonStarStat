qmodel <-
function(dfm1, method="sum", log2=TRUE){
    if(method=="fit" & log2==TRUE){
        lm1 <- NA; qres <- rep(NA, length(unique(dfm1$variable)))
        if(any(duplicated(dfm1$variable))){
            if("Frame" %in% colnames(dfm1)){                
                try(lm1 <- MCMCglmm(value~ 0 + variable, random=~ Frame + Frame:Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
                qres <- summary(lm1)$solutions[,1]
            }else{
                try(lm1 <- MCMCglmm(value~ 0 + variable, random=~ Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
                qres <- summary(lm1)$solutions[,1]
                
            }
        }else{
            try(lm1 <- glm(value~0+variable, data=dfm1), silent=TRUE)
            qres <- coef(lm1)
        }
        names(qres) <- sub("variable", "", names(qres))        
    }else{
        qres <- tapply(2^dfm1$value, as.character(dfm1$variable), FUN=method)
        if(log2==TRUE){
            qres <- log2(qres)
        }
    }
    PepNum <- length(unique(dfm1$Peptide))
    qres <- c(PepNum=PepNum, qres)
    return(qres)
}
