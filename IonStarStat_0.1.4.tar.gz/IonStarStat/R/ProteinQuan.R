ProteinQuan <-
function(eset, method="sum", log2=TRUE){
    df <- exprs(eset)
    SID <- sampleNames(eset)
    fData <- featureData(eset)
    if("Frame" %in% varLabels(fData)){
        df1 <- data.frame(Protein=factor(fData$Protein), Peptide=factor(fData$Peptide), Frame=factor(fData$Frame), exprs(eset))
        dfm <- melt(df1, c("Protein", "Peptide", "Frame"), SID)
    }else{
        df1 <- data.frame(Protein=factor(fData$Protein), Peptide=factor(fData$Peptide), exprs(eset))
        dfm <- melt(df1, c("Protein", "Peptide"), SID)        
    }
    qres <- lapply(split(dfm, dfm$Protein), function(x)qmodel(dfm1=x, method=method, log2=log2))
    qres <- do.call(rbind, qres)
    qres <- qres[, c("PepNum", sampleNames(eset))]
    return(qres)
}
