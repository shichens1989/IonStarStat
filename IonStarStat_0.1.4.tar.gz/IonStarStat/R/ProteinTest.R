ProteinTest <-
function(eset, condA, condB, padjust="fdr"){
    eset <- eset[,phenoData(eset)$condition %in% c(condA, condB)]
    df <- exprs(eset)
    SID <- sampleNames(eset)
    fData <- featureData(eset)

    if("Frame" %in% varLabels(fData)){
        df1 <- data.frame(Protein=fData$Protein, Peptide=fData$Peptide, Frame=fData$Frame, exprs(eset))
        dfm <- melt(df1, c("Protein", "Peptide", "Frame"), SID)
        TREAT <- rep(phenoData(eset)$condition, each=nrow(df1))
        dfm$TREAT <- factor(as.character(TREAT), levels=c(condB, condA))
        dfm$Peptide <- as.factor(dfm$Peptide)
        dfm$variable <- as.factor(dfm$variable)
        dfm$Frame <- as.factor(dfm$Frame)
    #dfm <- dfm[dfm$value!=0, ] # remove zero, imputation?    
    }else{
        df1 <- data.frame(Protein=fData$Protein, Peptide=fData$Peptide, exprs(eset))
        dfm <- melt(df1, c("Protein", "Peptide"), SID)
        TREAT <- rep(phenoData(eset)$condition, each=nrow(df1))
        dfm$TREAT <- factor(as.character(TREAT), levels=c(condB, condA))
        dfm$Peptide <- as.factor(dfm$Peptide)
        dfm$variable <- as.factor(dfm$variable)
    }
    
    #glmm model
    lmc <- tapply(1:nrow(dfm), as.character(dfm$Protein), function(x)pmodel(dfm[x,]))
    lmc <- as.data.frame(do.call(rbind, lmc))
    lmc$p.adj <- p.adjust(lmc$pMCMC, method=padjust)
    return(lmc)
}
