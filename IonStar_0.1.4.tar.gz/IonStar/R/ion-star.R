newProDataSet<-function (proData, condition, phenoData = NULL, featureData = NULL) 
{   proData <- unique(proData)
  message(paste("Input", length(unique(proData[, 1])), "proteins."))
  pf <- unique(proData[, c(2, 3)])
  dupFrame <- unique(pf[duplicated(pf[, 2]), 2])
  message(paste(length(dupFrame), "duplicated frames founded."))
  proData <- proData[!(proData[, 3] %in% dupFrame), ]
  message(paste(length(unique(proData[, 1])), "proteins left after filtering."))
  fData <- proData[, 1:3]
  PData <- as.matrix(proData[, -c(1:3)])
  rownames(PData) <- paste(fData[, 1], fData[, 2], fData[, 
                                                         3], sep = "|")
  colnames(fData) <- c("Protein", "Peptide", "Frame")
  if (is.null(phenoData)) {
    phenoData <- annotatedDataFrameFrom(PData, byrow = FALSE)
  }
  if (is.null(featureData)) {
    featureData <- annotatedDataFrameFrom(PData, byrow = TRUE)
  }
  featureData$Protein <- fData[, 1]
  featureData$Peptide <- fData[, 2]
  featureData$Frame <- fData[, 3]
  phenoData$condition <- condition
  prodat <- ExpressionSet(assayData = PData, phenoData = phenoData, 
                          featureData = featureData)
}

pnormalize<-function (eset, summarize = FALSE, method ) 
{
  if (class(eset) != "ExpressionSet") {
    stop("Input data is not an ExpressionSet!")
  }
  if (summarize == TRUE) {
    df <- exprs(eset)
    fn <- paste(featureData(eset)$Protein, featureData(eset)$Peptide, 
                sep = "|")
    PData <- tapply(1:nrow(df), fn, function(x) colSums(df[x, 
                                                           , drop = FALSE]))
    PData <- do.call(rbind, PData)
    featureData <- annotatedDataFrameFrom(PData, byrow = TRUE)
    pp <- do.call(rbind, strsplit(rownames(PData), split = "\\|"))
    featureData$Protein <- pp[, 1]
    featureData$Peptide <- pp[, 2]
    exprs(eset) <- PData
    featureData(eset) <- featureData
  }
  col.names <- colnames(exprs(eset))
  row.names <- rownames(exprs(eset))
  exprs(eset) <- log2(exprs(eset) + 1)
  
  if ( (!is.null(method)) && (method=="quantiles")) {
    eval(parse(text = paste("nmethod <- ", paste("normalize", 
                                                 method, sep = "."))))
    exprs(eset) <- nmethod(exprs(eset))
  }
  if ( (!is.null(method)) && (method=="TIC")){
    sum<-log2(apply(2^exprs(eset),2,sum))
    mean_all<-mean(sum)
    correction<-sum-mean_all
    exprs(eset)<-t(apply(exprs(eset),1,function(x){x-correction}))
  }
  colnames(exprs(eset)) <- col.names
  rownames(exprs(eset)) <- row.names
  return(eset)
}

OutlierPeptideRM<-function(eset,condition,variance,critM1,critM2,ratio=FALSE){
  if (class(eset) != "ExpressionSet") {
    stop("Input data is not an ExpressionSet!")
  }
  df<-exprs(eset)
  SID <- sampleNames(eset)
  fData <- featureData(eset)
  df0 <- data.frame(Protein = factor(fData$Protein), Peptide = factor(fData$Peptide),  df)
  mean<-t(apply(df,1,function(x){tapply(x,condition,FUN=mean,simplify=TRUE)}))
  input<-data.frame(Protein = factor(fData$Protein), Peptide = factor(fData$Peptide),  mean)
  if(ratio==TRUE){
    ratio<-mean[,-1]-mean[,1]
    input<- data.frame(Protein = factor(fData$Protein), Peptide = factor(fData$Peptide),  ratio)
  }
  LIST<-split(input, input$Protein)
  outlier_rm<-function(list){
    test<-as.data.frame(list)[,-c(1:2)]
    if(nrow(test)>=3){
      A<-pcout(test, makeplot = FALSE, explvar = variance, crit.M1 = critM1, crit.c1 = 2.5, crit.M2 = critM2, crit.c2 = 0.99, cs = 0.25, outbound = 0.25)$wfinal01
      return(A)
    } 
    else{
      A<-rep(1,nrow(test))
      names(A)<-row.names(test)
      return(A)
    }
  }
  analysis<-lapply(LIST,outlier_rm)
  outlier_result<-data.frame((unlist(analysis)))
  row.names(outlier_result)<-sub(".*\\.","",row.names(outlier_result))
  colnames(outlier_result)<-"outlier"
  message(paste(table(outlier_result)[1],"outliers were removed;",table(outlier_result)[2],"peptides left after outlier removal."))
  table(outlier_result)
  new_df<-cbind(df0,outlier_result)
  new_df<-new_df[new_df$outlier==1,!names(new_df) %in% c("outlier")]
  featureData <- annotatedDataFrameFrom(as.matrix(new_df[-c(1:2)]), byrow = TRUE)
  featureData$Protein <- new_df[, 1]
  featureData$Peptide <- new_df[, 2]
  eset<- ExpressionSet(assayData = as.matrix(new_df[,-c(1:2)]),featureData = featureData)
  return(eset)
}

SharedPeptideRM<-function(eset){
  pepdata<-exprs(eset)
  text<-row.names(pepdata)
  str<-strsplit(text,"|",fixed=TRUE)
  str<-do.call(rbind.data.frame, str)
  stringa<- str[,c(1:2)]
  colnames(stringa)<-c("ProteinAC","Peptideseq")
  newdata<-cbind(stringa,pepdata)
  row.names(newdata)<-NULL
  n_occur <- data.frame(table(newdata$Peptideseq))
  newdata2<-newdata[newdata$Peptideseq %in% n_occur$Var1[n_occur$Freq==1],]
  row.names(newdata2)<-paste(newdata2[,1],newdata2[,2],sep="|")
  featureData <- annotatedDataFrameFrom(as.matrix(newdata2), byrow = TRUE)
  featureData$Protein <- newdata2[, 1]
  featureData$Peptide <- newdata2[, 2]
  eset<- ExpressionSet(assayData = as.matrix(newdata2[,-c(1:2)]),featureData = featureData)
}

ProteinQuan<-function (eset, method = "sum", log2 = TRUE) 
{ df <- exprs(eset)
  SID <- sampleNames(eset)
  fData <- featureData(eset)
  if ("Frame" %in% varLabels(fData)) {
    df1 <- data.frame(Protein = factor(fData$Protein), Peptide = factor(fData$Peptide), 
                      Frame = factor(fData$Frame), exprs(eset))
    dfm <- melt(df1, c("Protein", "Peptide", "Frame"), SID)
  }
  else {
    df1 <- data.frame(Protein = factor(fData$Protein), Peptide = factor(fData$Peptide), 
                      exprs(eset))
    dfm <- melt(df1, c("Protein", "Peptide"), SID)
  }
  qres <- lapply(split(dfm, dfm$Protein), function(x) qmodel(dfm1 = x, method = method, log2 = log2))
  qres <- do.call(rbind, qres)
  qres <- qres[, c("PepNum", sampleNames(eset))]
  return(qres)
}

qmodel <-
  function(dfm1, method="sum", log2=TRUE){
    if(method=="fit" & log2==TRUE){
      lm1 <- NA; qres <- rep(NA, length(unique(dfm1$variable)))
      if(any(duplicated(dfm1$variable))){
        if("Frame" %in% colnames(dfm1)){                
          try(lm1 <- MCMCglmm(value~ 0 + variable, random=~ Frame + Frame:Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
          qres <- summary(lm1)$solutions[,1]
        }else{
          try(lmP1 <- MCMCglmm(value~ 0 + variable, random=~ Peptide, data=dfm1, verbose=FALSE), silent=TRUE)
          qres <- summary(lm1)$solutions[,1]
          
        }
      }else{
        try(lm1 <- glm(value~0+variable, data=dfm1), silent=TRUE)
        qres <- coef(lm1)
      }
      names(qres) <- sub("variable", "", names(qres))        
    }else{
      qres <- tapply(2^dfm1$value, as.character(dfm1$variable), FUN=method)
      if(log2==TRUE){
        qres <- log2(qres)
      }
    }
    PepNum <- length(unique(dfm1$Peptide))
    qres <- c(PepNum=PepNum, qres)
    return(qres)
  }
